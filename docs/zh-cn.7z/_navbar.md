* Language
  * [English](/)
  * [简体中文](/zh-cn/README.md)

* 联系作者
  * [Telegram](https://t.me/limbopluschat)
  * [哔哩哔哩](https://space.bilibili.com/625710211)
  * [Email](mailto:liujiayou2008@163.com)

* 更多
  * [Telegram频道](https://t.me/limboemuplus)
  * [博客](https://xtzyj.top)