<!-- _coverpage.md -->

![logo](/favicon.ico)

# Limbo Emulator Plus <small>2.0.3</small>

> Limbo Emulator的二次开发版本。

- 更精美的UI
- 更多CPU支持
- 内置多个UEFI启动固件
- 更快的启动速度
- 支持中文

[GitHub](https://github.com/Poempoat/LimboEmulatorPlus)
[下载](#downloads)
[开始吧](#limbo-emulator-plus)

![](bg.png)